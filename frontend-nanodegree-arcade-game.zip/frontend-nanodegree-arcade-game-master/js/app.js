// Enemies our player must avoid
var Enemy = function(x,y,speed) {
    // Variables applied to each of our instances go here,
    // we've provided one for you to get started
this.x=x;
this.y=y;
this.speed=speed;// speed of the bugs 
    // The image/sprite for our enemies, this uses
    // a helper we've provided to easily load images
    this.sprite = 'images/enemy-bug.png';
};

// Update the enemy's position, required method for game
// Parameter: dt, a time delta between ticks
Enemy.prototype.update = function(dt) {
    // You should multiply any movement by the dt parameter
    // which will ensure the game runs at the same speed for
    // all computers.
    this.x += this.speed * dt;
// for repate the move of the enemy when they in limits
 if (this.x >410) {
    this.x = -50;
};

/// when the enemy and the player are in the same place the player return to the beginning
 if (player.x < this.x + 50 && player.y < this.y + 50 && player.x + 50 > this.x &&  50 + player.y > this.y) {
    player.x = 200;
    player.y = 400;
}; 

};

// Draw the enemy on the screen, required method for game
Enemy.prototype.render = function() {
    ctx.drawImage(Resources.get(this.sprite), this.x, this.y);
};


Enemy.prototype.handleInput=function(){
 
};

// Place all enemy objects in an array called allEnemies
const allEnemies=[];

// Place the player object in a variable called player
// class the player with x and y and the image of princess  
var Player= function(x,y){
    this.x=x;
    this.y=y;

 this.player = 'images/char-princess-girl.png';
};

Player.prototype.update=function(){

};
Player.prototype.render = function () {
    ctx.drawImage(Resources.get(this.player), this.x, this.y);
};
Player.prototype.handleInput=function(key){
// the key value is left or right or up or down key in keyboard 
// the left or right key change the x value only and the limit of x is 400 
// the up or down key change the y value only and the limit of y is 400 

    if (key == 'left' && this.x > 0) {
        this.x -= 50;
       
    };
    if (key == 'down' && this.y < 400) {
        this.y += 50;
      
    };
    if (key == 'right' && this.x < 400) {
        this.x += 50;
       
    };

    if (key == 'up' && this.y > 0) {
        this.y -= 50;
        
    };
    if( this.y ===0){
       
        this.x = 202;
        this.y = 400;
       alert("YOU ARE WIN !!");
    
    };
   
};
let player = new Player(205, 400);
var enemyLoc = [63, 147, 230 ];// location of the enemis 
enemyLoc.forEach(function (locY) {
    enemy = new Enemy(0, locY, 150);
    
    allEnemies.push(enemy);
   
});
var enemyLoc2 = [63 ,200];// location of the enemis group 2 that different from group 1
 enemyLoc2.forEach(function (locY) {
    enemy = new Enemy(340, locY, 150);
    allEnemies.push(enemy);
}); 
// when the user pres the button the speed of the enemies will increase by 20 
function harder(){
    allEnemies.forEach(function (em) {
        em.speed+=20;
    }); 
     
  
}

// This listens for key presses and sends the keys to your
// Player.handleInput() method. You don't need to modify this.
document.addEventListener('keyup', function(e) {
    var allowedKeys = {
        37: 'left',
        38: 'up',
        39: 'right',
        40: 'down'
    };

    player.handleInput(allowedKeys[e.keyCode]);
});
