# Classic Arcade Game Clone Project
Classic Arcade Game has long been a favorite game for all generations. It is easy to play,the idea of it is to make player go to the other side without touching the enemy (bugs) , once the player touch it the player return to the beginning .

if it is easy for you there is button harder if you click on it the speed of the enemy (bugs).


## Table of Contents

- [Instructions](#instructions)
- [Contributing](#contributing)

## Instructions

The  project has some HTML and CSS and java script files  to display the Memory Game project and to play this game .

to run the game open the `index.html` move the player with the arrows on the keyboard

in the `app.js` we create the player and the enemy class and the movement.


## Contributing

This game does not tolerate any contribution, it is udacity project for nano degree
